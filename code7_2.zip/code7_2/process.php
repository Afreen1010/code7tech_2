<?php
$db_user = "root";
$db_pass = "";
$db_name = "profile";

$db = new PDO('mysql:host=localhost;dbname=' . $db_name . ';charset=utf8', $db_user, $db_pass);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

?>
<?php

if(isset($_POST)){

	$firstname 		= $_POST['firstname'];
	$lastname 		= $_POST['lastname'];
	$email 			= $_POST['email'];
	$phonenumber	= $_POST['phonenumber'];
	$password 		= $_POST['password'];
	$address        = $_POST['address'];
	$nation         = $_POST['nation'];
	$gender         = $_POST['gender'];
	$language       = $_POST['language'];
	$dob            = $_POST['dob'];
	$twitter        = $_POST['twitter'];
	$linkedin       = $_POST['linkedin'];
	$facebook       = $_POST['facebook'];
	$google         = $_POST['google'];
	$slogan         = $_POST['slogan'];
	

		$sql = "INSERT INTO users (firstname,
		                           lastname,
                             	   email,
								   phonenumber,
								   password,
								   address,
								   nation,
								   gender,
								   language,
								   dob,
								   twitter,
								   linkedin,
								   facebook,
								   google,
								   slogan ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		$stmtinsert = $db->prepare($sql);
		$result = $stmtinsert->execute([$firstname,
										$lastname,
									    $email,
									    $phonenumber,
									    $password,
										$address,
										$nation,
										$gender,
										$language, 
										$dob,
										$twitter,
										$linkedin,
										$facebook,
										$google,
										$slogan	
									]);
		if($result){
			echo 'Successfully saved.';
		}else{
			echo 'There were erros while saving the data.';
		}
}else{
	echo 'No data';
}