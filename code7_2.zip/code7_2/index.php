<?php
session_start();
include('config.php');
$sql1=mysqli_query($db,"SELECT * FROM users");

if (mysqli_num_rows($sql1) > 0){
    

    }else{
    echo "<script>alert('No more users Redirecting to registration page');</script>";
    echo '<script>setTimeout(function(){ location.href = "registration.php"; }, 1);</script>';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Styles/edit.css">
</head>
<body>
<form action="edit.php" method="post">
<table  id="sample-table-1">
                <thead>
                    <tr>
                    <th>Sr.no</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Password</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Nation</th>
                    <th>Gender</th>
                    <th>DOB</th>
                    <th>Language</th>
                    <th>Twitter</th>
                    <th>Linked in</th>
                    <th>Facebook</th>
                    <th>Google</th>
                    <th>Slogan</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $sql=mysqli_query($db,"SELECT * FROM users");
                $i=1;
                while($row=mysqli_fetch_array($sql)){ ?>
                <tr>
                    <td><input type="text"  value="<?php echo $i; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['firstname']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['lastname']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['password']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['email']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['phonenumber']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['address']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['nation']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['gender']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['dob']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['language']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['twitter']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['linkedin']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['facebook']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['google']; ?>"></td>
                    <td><input type="text"  value="<?php echo $row['slogan']; ?>"></td>
                    <td>
                        <button type="submit" name="submit1" value="<?php echo $row['profile_id']; ?>"><i class="far fa-edit"></i></button>
                        <button type="submit" name="submit2" value="<?php echo $row['profile_id']; ?>"><i class="far fa-trash-alt"></i></button>
                    </td>
                    
                                                                      
                    
                    
                    <?php $i=$i+1; } ?>
                </tr>
                </tbody>

</table>
</form>

<script src="https://kit.fontawesome.com/b8e3505483.js" crossorigin="anonymous"></script>
</body>
</html>